/*
 * (C) Christelijke Hogeschool Windesheim 2002
 *             *** portab.h ***
 */

#define T_Unsigned_8     unsigned char 
#define T_Signed_8       signed char
#define T_Unsigned_16    unsigned int
#define T_Signed_16      signed int

#define false    0
#define true     1
