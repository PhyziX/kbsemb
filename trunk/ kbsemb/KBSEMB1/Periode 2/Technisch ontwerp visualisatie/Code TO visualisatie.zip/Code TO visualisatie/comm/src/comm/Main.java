package comm;

import java.util.*;
import javax.comm.*;
import java.io.*;

/**
 *
 * @author Asteroid
 */
public class Main {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String drivername = "com.sun.comm.Win32Driver";
        Enumeration portlist;
        CommPortIdentifier cpi = null;
        String defaultPort = "COM5";
        String appName = "comm";
        SerialPort port;
        InputStream input;
        int baudrate;
        int read = 0;
        
        try{
            CommDriver driver = (CommDriver) Class.forName(drivername).newInstance();
            driver.initialize();
            portlist = CommPortIdentifier.getPortIdentifiers();
            cpi = (CommPortIdentifier) portlist.nextElement();
            
            while((portlist.hasMoreElements()) && (!cpi.getName().equals(defaultPort))) {
                cpi = (CommPortIdentifier) portlist.nextElement();
            }
            
            port = (SerialPort) cpi.open(appName, 2000);
            input = port.getInputStream();
            port.setSerialPortParams(9600, SerialPort.DATABITS_8, 
                       SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
            while(read == 0){
                read = input.read();
            }
            System.out.println(read);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}