#include <stdint.h>

#include <avr/io.h>


void USART_Init(void)

{

	// Set baud rate (9600)
	UBRRL = 0x67;

	// Set frame format to 8 data bits, no parity, 2 stop bits
	UCSRC = 0x0E;

	// Enable receiver and transmitter
	UCSRB = 0x08; 

}


void USART_SendByte(uint8_t Data)
{

	// Wait if a byte is being transmitted
	while((UCSRA&(1<<UDRE)) == 0);

	// Transmit data
	UDR = Data;

}

int main(void)

{

	uint8_t Data;


	// Initialise USART

	USART_Init();


	// Send string

	USART_SendByte('A');

}

